# BLACKLORD TECH INC - Full Stack Platform

A modern, production-ready full-stack web application for selling Pterodactyl hosting panels and automation bots with integrated wallet and multi-payment support.

## 🎨 Features

### Design
- **Dark Cyberpunk UI**: Neon cyan and purple accents throughout
- **Fire/Coal Background**: Stunning animated background imagery
- **Responsive Design**: Mobile-first approach with Tailwind CSS 4
- **Modern Components**: Built with shadcn/ui and Radix UI

### Functionality
- **User Authentication**: Manus OAuth with session management
- **Wallet System**: KSH-based balance tracking
- **Payment Integration**: Paystack, M-Pesa STK Push, Pesapal
- **Product Catalog**: Hosting panels and automation bots
- **Order Management**: Track active services and purchases
- **Admin Dashboard**: Full control over users, transactions, and orders
- **Role-Based Access**: Admin and user roles with protected routes

### Technology Stack
- **Frontend**: React 19, TypeScript, Tailwind CSS 4, shadcn/ui
- **Backend**: Express 4, tRPC 11, Node.js
- **Database**: MySQL/Neon Postgres with Drizzle ORM
- **Authentication**: Manus OAuth
- **Deployment**: Vercel (serverless)

## 📁 Project Structure

```
blacklord-tech-inc/
├── client/                          # React Frontend
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx            # Landing page with hero
│   │   │   ├── Dashboard.tsx       # User dashboard
│   │   │   ├── Wallet.tsx          # Wallet management
│   │   │   ├── Products.tsx        # Product listing
│   │   │   ├── Admin.tsx           # Admin dashboard
│   │   │   ├── AdminUsers.tsx      # User management
│   │   │   ├── AdminTransactions.tsx # Transaction management
│   │   │   ├── AdminOrders.tsx     # Order management
│   │   │   └── NotFound.tsx        # 404 page
│   │   ├── components/
│   │   │   ├── PaymentMethodSelector.tsx
│   │   │   ├── WalletBalance.tsx
│   │   │   ├── TransactionHistory.tsx
│   │   │   ├── ProductCard.tsx
│   │   │   ├── DashboardLayout.tsx
│   │   │   ├── AIChatBox.tsx
│   │   │   ├── Map.tsx
│   │   │   ├── ui/                 # shadcn/ui components
│   │   │   └── ErrorBoundary.tsx
│   │   ├── lib/
│   │   │   ├── trpc.ts            # tRPC client
│   │   │   └── utils.ts           # Utilities
│   │   ├── hooks/
│   │   │   ├── useAuth.ts         # Auth hook
│   │   │   └── useComposition.ts
│   │   ├── contexts/
│   │   │   └── ThemeContext.tsx
│   │   ├── App.tsx                # Main app with routing
│   │   ├── main.tsx               # Entry point
│   │   └── index.css              # Global styles
│   ├── public/
│   │   ├── favicon.ico
│   │   └── robots.txt
│   └── index.html
├── server/                          # Express Backend
│   ├── routers.ts                  # tRPC procedures
│   ├── db.ts                       # Database queries
│   ├── auth.logout.test.ts         # Tests
│   ├── seed-products.ts            # Database seeding
│   └── _core/
│       ├── index.ts               # Server entry point
│       ├── context.ts             # tRPC context
│       ├── trpc.ts                # tRPC setup
│       ├── oauth.ts               # OAuth handling
│       ├── cookies.ts             # Session management
│       ├── env.ts                 # Environment variables
│       └── systemRouter.ts        # System procedures
├── drizzle/                         # Database
│   ├── schema.ts                  # Table definitions
│   ├── migrations/                # Migration files
│   └── relations.ts               # Table relationships
├── shared/                          # Shared Code
│   ├── const.ts                   # Constants
│   ├── types.ts                   # Shared types
│   └── _core/
│       └── errors.ts              # Error types
├── storage/                         # S3 Storage
│   └── storage.ts                 # Storage helpers
├── package.json
├── tsconfig.json
├── vite.config.ts
├── vitest.config.ts
├── drizzle.config.ts
├── vercel.json                     # Vercel config
├── DEPLOYMENT_GUIDE.md             # Deployment instructions
└── README_FULL.md                  # This file
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- pnpm
- MySQL or Neon Postgres database

### Installation

```bash
# Install dependencies
pnpm install

# Set up environment variables
cp .env.example .env
# Edit .env with your configuration

# Initialize database
pnpm drizzle-kit generate
pnpm drizzle-kit migrate

# Seed sample products
pnpm seed

# Start development server
pnpm dev
```

Visit `http://localhost:3000` to see your app.

## 📊 Database Schema

### Users Table
- `id`: Primary key
- `openId`: OAuth identifier
- `name`: User name
- `email`: User email
- `role`: admin | user
- `createdAt`, `updatedAt`, `lastSignedIn`: Timestamps

### Wallets Table
- `id`: Primary key
- `userId`: Foreign key to users
- `balance`: KSH balance (decimal)
- `createdAt`, `updatedAt`: Timestamps

### Transactions Table
- `id`: Primary key
- `userId`: Foreign key to users
- `type`: deposit | withdrawal | purchase
- `amount`: Transaction amount
- `paymentMethod`: paystack | mpesa | pesapal
- `status`: pending | completed | failed
- `reference`: Payment gateway reference
- `createdAt`, `updatedAt`: Timestamps

### Products Table
- `id`: Primary key
- `name`: Product name
- `description`: Product description
- `category`: panel | bot | addon
- `price`: KSH price
- `billingCycle`: monthly | yearly
- `features`: JSON array of features
- `active`: 1 | 0
- `createdAt`, `updatedAt`: Timestamps

### Orders Table
- `id`: Primary key
- `userId`: Foreign key to users
- `productId`: Foreign key to products
- `quantity`: Order quantity
- `totalPrice`: Total price in KSH
- `status`: pending | active | suspended | cancelled
- `serviceId`: External service identifier
- `createdAt`, `updatedAt`: Timestamps

## 🔌 API Routes (tRPC)

### Auth
```typescript
auth.me()              // Get current user
auth.logout()          // Logout user
```

### Wallet
```typescript
wallet.getBalance()    // Get wallet balance
wallet.getHistory()    // Get transaction history
wallet.deposit({       // Initiate deposit
  amount: string
  paymentMethod: "paystack" | "mpesa" | "pesapal"
  reference?: string
})
wallet.confirmDeposit({ // Confirm payment
  reference: string
  amount: string
})
```

### Products
```typescript
products.list()        // List all products
products.getById({     // Get product details
  id: number
})
```

### Orders
```typescript
orders.create({        // Create order
  productId: number
  quantity?: number
})
orders.list()          // Get user orders
```

### Admin (Protected)
```typescript
admin.users()          // List all users
admin.transactions()   // List all transactions
admin.orders()         // List all orders
```

## 🎯 Pages

| Route | Description | Protected |
|-------|-------------|-----------|
| `/` | Landing page with hero section | No |
| `/dashboard` | User dashboard with wallet and services | Yes |
| `/wallet` | Wallet management and deposits | Yes |
| `/products` | Product catalog | No |
| `/admin` | Admin dashboard | Yes (Admin only) |
| `/admin/users` | User management | Yes (Admin only) |
| `/admin/transactions` | Transaction management | Yes (Admin only) |
| `/admin/orders` | Order management | Yes (Admin only) |
| `/404` | Not found page | No |

## 💳 Payment Integration

### Paystack
- Card and bank transfer support
- Webhook verification required
- [Setup Guide](https://paystack.com/docs)

### M-Pesa STK Push
- Mobile money via STK push
- Safaricom integration
- [Setup Guide](https://developer.safaricom.co.ke)

### Pesapal
- Multiple payment methods
- Easy integration
- [Setup Guide](https://pesapal.com/api)

## 🎨 Customization

### Colors
Edit `client/src/index.css` to change the cyberpunk theme:
- Primary: Neon Cyan (#00d2ff)
- Secondary: Neon Purple (#9d50bb)
- Background: Pure Black (#000000)

### Background Image
The fire/coal background is stored at `/manus-storage/1934783_dfa0fb10.jpg`

### Products
Seed new products by editing `server/seed-products.ts` and running `pnpm seed`

## 🧪 Testing

```bash
# Run tests
pnpm test

# Run tests in watch mode
pnpm test:watch
```

## 📦 Building

```bash
# Build for production
pnpm build

# Preview production build
pnpm preview
```

## 🚢 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Add environment variables
5. Deploy

See [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) for detailed instructions.

## 📝 Environment Variables

```env
# Database
DATABASE_URL=mysql://user:password@host/db

# Auth
JWT_SECRET=your-secret
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# API
VITE_FRONTEND_FORGE_API_KEY=key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=key
BUILT_IN_FORGE_API_URL=https://api.manus.im
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

For issues and questions:
- Check [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)
- Review [IMPLEMENTATION_NOTES.md](./IMPLEMENTATION_NOTES.md)
- Visit [Manus Documentation](https://manus.im/docs)

## 🎯 Roadmap

- [ ] Complete Paystack integration
- [ ] Complete M-Pesa STK Push integration
- [ ] Complete Pesapal integration
- [ ] Email notifications
- [ ] SMS notifications
- [ ] Advanced analytics
- [ ] Multi-language support
- [ ] Dark/Light theme toggle

---

**BLACKLORD TECH INC** - Powering the future of hosting and automation. 🚀
