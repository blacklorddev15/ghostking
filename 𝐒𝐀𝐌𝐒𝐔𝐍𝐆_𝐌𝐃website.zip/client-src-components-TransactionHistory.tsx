import { Card } from "@/components/ui/card";

interface TransactionHistoryProps {
  transactions: any[];
  maxHeight?: string;
}

export function TransactionHistory({ transactions, maxHeight = "max-h-96" }: TransactionHistoryProps) {
  return (
    <Card className="bg-black/50 border-cyan-500/30 p-6">
      <h3 className="font-semibold mb-4">Recent Transactions</h3>
      <div className={`space-y-3 ${maxHeight} overflow-y-auto`}>
        {transactions && transactions.length > 0 ? (
          transactions.map((tx: any) => (
            <div key={tx.id} className="pb-3 border-b border-cyan-500/20 last:border-0">
              <div className="flex justify-between items-start">
                <div>
                  <div className="font-medium capitalize">{tx.type}</div>
                  <div className="text-xs text-gray-400">{tx.paymentMethod || "System"}</div>
                </div>
                <div className="text-right">
                  <div className={`font-bold ${tx.type === "deposit" ? "text-green-400" : "text-red-400"}`}>
                    {tx.type === "deposit" ? "+" : "-"}KSH {parseFloat(tx.amount as any).toLocaleString("en-KE", { minimumFractionDigits: 2 })}
                  </div>
                  <div className={`text-xs ${
                    tx.status === "completed" ? "text-green-400" :
                    tx.status === "pending" ? "text-yellow-400" :
                    "text-red-400"
                  }`}>
                    {tx.status}
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-gray-400 text-center py-8">No transactions yet</p>
        )}
      </div>
    </Card>
  );
}
