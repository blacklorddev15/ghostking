# BLACKLORD TECH INC - Implementation Notes

## Key Assets
- **Background Image**: `/manus-storage/1934783_dfa0fb10.jpg` (Fire/coal cyberpunk background)
- **Logo**: Generated custom neon lightning bolt logo

## Architecture Overview
- **Frontend**: React 19 + Tailwind 4 + TypeScript
- **Backend**: Express 4 + tRPC 11
- **Database**: MySQL (via template, can be migrated to Neon Postgres)
- **Authentication**: Manus OAuth (built-in) + Session cookies
- **Payment**: Paystack, M-Pesa STK Push, Pesapal (integration pending)

## Database Schema
- `users`: User accounts with role-based access (admin/user)
- `wallets`: User wallet balances in KSH
- `transactions`: Deposit/withdrawal/purchase history
- `products`: Hosting plans and bot services
- `orders`: User service purchases

## API Routes (tRPC)
- `auth.me`: Get current user
- `auth.logout`: Logout user
- `wallet.getBalance`: Get user wallet balance
- `wallet.getHistory`: Get transaction history
- `wallet.deposit`: Initiate deposit
- `wallet.confirmDeposit`: Confirm payment and update balance
- `products.list`: List all active products
- `products.getById`: Get product details
- `orders.create`: Create new order (deducts from wallet)
- `orders.list`: Get user's orders
- `admin.users`: List all users (admin only)
- `admin.transactions`: List all transactions (admin only)
- `admin.orders`: List all orders (admin only)

## Frontend Pages
- `/`: Home page with hero section
- `/dashboard`: User dashboard with wallet balance and active services
- `/wallet`: Wallet management with payment method selection
- `/products`: Products/plans listing with KSH pricing
- `/404`: Not found page

## Color Scheme (Cyberpunk Dark)
- **Primary**: Neon Cyan (#00d2ff)
- **Secondary**: Neon Purple (#9d50bb)
- **Background**: Pure Black (#000000)
- **Accents**: Fire orange/red for highlights

## Next Steps to Complete
1. Migrate from MySQL to Neon Postgres (if needed)
2. Implement custom JWT auth with password hashing
3. Add dedicated login/signup pages
4. Integrate Paystack, M-Pesa, and Pesapal payment APIs
5. Create admin panel pages
6. Extract reusable components
7. Add comprehensive testing

## Payment Integration Notes
- Paystack: Card/Bank transfers
- M-Pesa: STK Push for mobile money
- Pesapal: Multiple payment methods
- All deposits go directly to user wallet balance
- Transactions are logged with payment method and reference ID
