import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getOrCreateWallet, getWalletBalance, updateWalletBalance, createTransaction, getTransactionHistory, getActiveProducts, getProductById, createOrder, getUserOrders, getAllUsers, getAllTransactions, getAllOrders } from "./db";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Wallet routes
  wallet: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const balance = await getWalletBalance(ctx.user.id);
      return { balance };
    }),

    getHistory: protectedProcedure.query(async ({ ctx }) => {
      const transactions = await getTransactionHistory(ctx.user.id);
      return { transactions };
    }),

    deposit: protectedProcedure
      .input(z.object({
        amount: z.string(),
        paymentMethod: z.enum(["paystack", "mpesa", "pesapal"]),
        reference: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Create transaction record
        await createTransaction({
          userId: ctx.user.id,
          type: "deposit",
          amount: input.amount as any,
          paymentMethod: input.paymentMethod,
          status: "pending",
          reference: input.reference,
          description: `Deposit via ${input.paymentMethod}`,
        });

        return { success: true, message: "Deposit initiated" };
      }),

    confirmDeposit: protectedProcedure
      .input(z.object({
        reference: z.string(),
        amount: z.string(),
      }))
      .mutation(async ({ ctx, input }) => {
        // Update transaction status
        const db = await require("./db").getDb();
        if (!db) throw new Error("Database not available");

        // Get current balance
        const currentBalance = await getWalletBalance(ctx.user.id);
        const newBalance = (parseFloat(currentBalance) + parseFloat(input.amount)).toFixed(2);

        // Update wallet
        await updateWalletBalance(ctx.user.id, newBalance);

        // Update transaction
        await db.update(require("../drizzle/schema").transactions)
          .set({ status: "completed" })
          .where(require("drizzle-orm").eq(require("../drizzle/schema").transactions.reference, input.reference));

        return { success: true, newBalance };
      }),
  }),

  // Products routes
  products: router({
    list: publicProcedure.query(async () => {
      const products = await getActiveProducts();
      return { products };
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await getProductById(input.id);
        if (!product) throw new TRPCError({ code: "NOT_FOUND" });
        return { product };
      }),
  }),

  // Orders routes
  orders: router({
    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        quantity: z.number().default(1),
      }))
      .mutation(async ({ ctx, input }) => {
        const product = await getProductById(input.productId);
        if (!product) throw new TRPCError({ code: "NOT_FOUND" });

        const totalPrice = (parseFloat(product.price as any) * input.quantity).toFixed(2);

        // Check wallet balance
        const balance = await getWalletBalance(ctx.user.id);
        if (parseFloat(balance) < parseFloat(totalPrice)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Insufficient wallet balance" });
        }

        // Deduct from wallet
        const newBalance = (parseFloat(balance) - parseFloat(totalPrice)).toFixed(2);
        await updateWalletBalance(ctx.user.id, newBalance);

        // Create order
        await createOrder({
          userId: ctx.user.id,
          productId: input.productId,
          quantity: input.quantity,
          totalPrice: totalPrice as any,
          status: "active",
        });

        // Log transaction
        await createTransaction({
          userId: ctx.user.id,
          type: "purchase",
          amount: totalPrice as any,
          status: "completed",
          description: `Purchase: ${product.name}`,
        });

        return { success: true, newBalance };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      const orders = await getUserOrders(ctx.user.id);
      return { orders };
    }),
  }),

  // Admin routes
  admin: router({
    users: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .query(async () => {
        const users = await getAllUsers();
        return { users };
      }),

    transactions: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .query(async () => {
        const transactions = await getAllTransactions();
        return { transactions };
      }),

    orders: protectedProcedure
      .use(async ({ ctx, next }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        return next({ ctx });
      })
      .query(async () => {
        const orders = await getAllOrders();
        return { orders };
      }),
  }),
});

export type AppRouter = typeof appRouter;
