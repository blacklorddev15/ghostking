import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Loader2, Zap } from "lucide-react";
import { Link } from "wouter";

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    description?: string;
    price: string;
    billingCycle?: string;
    features?: string;
    category?: string;
  };
  isAuthenticated: boolean;
  isLoading?: boolean;
  onPurchase: (productId: number) => void;
}

export function ProductCard({ product, isAuthenticated, isLoading = false, onPurchase }: ProductCardProps) {
  const features = product.features ? JSON.parse(product.features) : [];
  const isPurple = product.category === "bot";
  
  // Neon glow classes
  const glowClass = isPurple ? "neon-glow-purple" : "neon-glow-cyan";
  const animateGlowClass = isPurple ? "animate-glow-purple" : "animate-glow-cyan";
  const accentColor = isPurple ? "text-purple-400" : "text-cyan-400";
  const textGlowClass = isPurple ? "text-glow-purple" : "text-glow-cyan";
  
  const buttonClass = isPurple 
    ? "bg-gradient-to-r from-purple-500 to-cyan-600 hover:from-purple-600 hover:to-cyan-700"
    : "bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700";

  return (
    <Card className={`bg-black/50 border-2 transition-glow hover-scale card-hover glowing-border ${glowClass} ${animateGlowClass} ${isPurple ? "border-purple-500/40" : "border-cyan-500/40"} p-6 flex flex-col relative overflow-hidden`}>
      {/* Glow accent line at top */}
      <div className={`absolute top-0 left-0 right-0 h-px ${isPurple ? "bg-gradient-to-r from-transparent via-purple-500 to-transparent" : "bg-gradient-to-r from-transparent via-cyan-500 to-transparent"}`} />
      
      <h3 className={`text-2xl font-bold mb-2 ${textGlowClass}`}>
        {product.name}
      </h3>
      <p className="text-gray-400 text-sm mb-4">{product.description}</p>

      {/* Features */}
      {features.length > 0 && (
        <ul className="space-y-2 mb-6 flex-grow">
          {features.map((feature: string, idx: number) => (
            <li key={idx} className="flex items-center gap-2 text-sm group">
              <Check className={`w-4 h-4 ${accentColor} transition-transform group-hover:scale-125`} />
              <span className="group-hover:text-white transition-colors">{feature}</span>
            </li>
          ))}
        </ul>
      )}

      {/* Price Section */}
      <div className={`mb-6 border-t ${isPurple ? "border-purple-500/30" : "border-cyan-500/30"} pt-4`}>
        <div className={`text-3xl font-bold ${accentColor} ${textGlowClass}`}>
          KSH {parseFloat(product.price).toLocaleString("en-KE", { minimumFractionDigits: 2 })}
        </div>
        <div className="text-sm text-gray-400">/{product.billingCycle || "monthly"}</div>
      </div>

      {/* Purchase Button */}
      {isAuthenticated ? (
        <Button
          onClick={() => onPurchase(product.id)}
          disabled={isLoading}
          className={`w-full ${buttonClass} transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/50 group relative overflow-hidden`}
        >
          <span className="relative z-10 flex items-center justify-center gap-2">
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 transition-transform group-hover:scale-110" />
                Deploy Now
              </>
            )}
          </span>
          {/* Button glow effect on hover */}
          <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/20 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </Button>
      ) : (
        <Link href="/signup">
          <Button className={`w-full ${buttonClass} transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/50 group relative overflow-hidden`}>
            <span className="relative z-10 flex items-center justify-center gap-2">
              <Zap className="w-4 h-4 transition-transform group-hover:scale-110" />
              Sign Up to Purchase
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/20 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Button>
        </Link>
      )}

      {/* Glow accent line at bottom */}
      <div className={`absolute bottom-0 left-0 right-0 h-px ${isPurple ? "bg-gradient-to-r from-transparent via-purple-500 to-transparent" : "bg-gradient-to-r from-transparent via-cyan-500 to-transparent"}`} />
    </Card>
  );
}
