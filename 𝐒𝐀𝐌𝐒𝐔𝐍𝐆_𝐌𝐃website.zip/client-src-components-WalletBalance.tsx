import { Card } from "@/components/ui/card";
import { Wallet, Loader2 } from "lucide-react";

interface WalletBalanceProps {
  balance: string;
  isLoading?: boolean;
  showIcon?: boolean;
}

export function WalletBalance({ balance, isLoading = false, showIcon = true }: WalletBalanceProps) {
  return (
    <Card className="bg-gradient-to-br from-cyan-500/20 to-purple-500/20 border-cyan-500/30 p-6">
      {showIcon && (
        <div className="flex items-center gap-3 mb-4">
          <Wallet className="w-8 h-8 text-cyan-400" />
          <h3 className="text-lg font-semibold">Current Balance</h3>
        </div>
      )}
      {isLoading ? (
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
      ) : (
        <div className="text-4xl font-bold text-cyan-400">
          KSH {parseFloat(balance || "0").toLocaleString("en-KE", { minimumFractionDigits: 2 })}
        </div>
      )}
    </Card>
  );
}
