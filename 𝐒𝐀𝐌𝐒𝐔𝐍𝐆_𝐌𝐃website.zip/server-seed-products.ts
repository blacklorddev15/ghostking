import { getDb } from "./db";
import { products } from "../drizzle/schema";

async function seedProducts() {
  const db = await getDb();
  if (!db) {
    console.error("Database not available");
    process.exit(1);
  }

  try {
    // Clear existing products
    // await db.delete(products);

    // Insert sample products
    const sampleProducts = [
      {
        name: "Starter Panel",
        description: "Perfect for small game servers and projects",
        category: "panel" as const,
        price: "500.00",
        billingCycle: "monthly",
        features: JSON.stringify([
          "2GB RAM",
          "10GB NVMe SSD",
          "1 CPU Core",
          "24/7 Support",
          "Auto Backups",
        ]),
        active: 1,
      },
      {
        name: "Pro Panel",
        description: "For growing communities and businesses",
        category: "panel" as const,
        price: "1200.00",
        billingCycle: "monthly",
        features: JSON.stringify([
          "8GB RAM",
          "50GB NVMe SSD",
          "4 CPU Cores",
          "Priority Support",
          "Advanced Analytics",
          "Unlimited Backups",
        ]),
        active: 1,
      },
      {
        name: "Elite Panel",
        description: "Enterprise-grade hosting solution",
        category: "panel" as const,
        price: "2500.00",
        billingCycle: "monthly",
        features: JSON.stringify([
          "16GB RAM",
          "100GB NVMe SSD",
          "8 CPU Cores",
          "Dedicated Account Manager",
          "Custom Configurations",
          "DDoS Protection",
        ]),
        active: 1,
      },
      {
        name: "WhatsApp Bot",
        description: "Automate customer support and engagement",
        category: "bot" as const,
        price: "1500.00",
        billingCycle: "monthly",
        features: JSON.stringify([
          "Unlimited Messages",
          "AI Responses",
          "24/7 Automation",
          "Analytics Dashboard",
          "Custom Workflows",
        ]),
        active: 1,
      },
      {
        name: "Telegram Bot",
        description: "Advanced Telegram automation",
        category: "bot" as const,
        price: "1000.00",
        billingCycle: "monthly",
        features: JSON.stringify([
          "Group Management",
          "Auto Moderation",
          "Custom Commands",
          "User Analytics",
          "24/7 Uptime",
        ]),
        active: 1,
      },
    ];

    for (const product of sampleProducts) {
      await db.insert(products).values(product as any);
    }

    console.log("✅ Products seeded successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error seeding products:", error);
    process.exit(1);
  }
}

seedProducts();
