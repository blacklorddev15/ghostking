# BLACKLORD TECH INC - Vercel Deployment Guide

## Overview

This is a complete full-stack web application built with React 19, Express 4, tRPC 11, and MySQL/Neon database. It features a dark cyberpunk UI with payment integrations for Paystack, M-Pesa, and Pesapal.

## Prerequisites

- Node.js 18+ and pnpm
- MySQL or Neon Postgres database
- Vercel account
- Manus OAuth credentials (for authentication)

## Local Development

### 1. Install Dependencies

```bash
pnpm install
```

### 2. Set Up Environment Variables

Create a `.env` file in the root directory:

```env
# Database
DATABASE_URL=mysql://user:password@host:port/database

# Authentication
JWT_SECRET=your-secret-key-here
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# API Keys
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-backend-key
BUILT_IN_FORGE_API_URL=https://api.manus.im
```

### 3. Initialize Database

```bash
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

### 4. Seed Sample Products

```bash
pnpm seed
```

### 5. Start Development Server

```bash
pnpm dev
```

The app will be available at `http://localhost:3000`

## Deployment to Vercel

### 1. Push Code to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/blacklord-tech-inc.git
git push -u origin main
```

### 2. Connect to Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import your GitHub repository
4. Select the project and click "Import"

### 3. Configure Environment Variables

In Vercel dashboard, go to Settings → Environment Variables and add:

```
DATABASE_URL=your-mysql-or-neon-connection-string
JWT_SECRET=your-secret-key
VITE_APP_ID=your-manus-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
VITE_FRONTEND_FORGE_API_KEY=your-frontend-key
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-backend-key
BUILT_IN_FORGE_API_URL=https://api.manus.im
```

### 4. Deploy

Click "Deploy" and wait for the build to complete. Your site will be live at `your-project.vercel.app`

## Database Setup

### Using Neon (Recommended)

1. Create account at [neon.tech](https://neon.tech)
2. Create a new project
3. Copy the connection string
4. Update `DATABASE_URL` in Vercel environment variables

### Using MySQL

1. Use any MySQL hosting (AWS RDS, DigitalOcean, etc.)
2. Create a new database
3. Get the connection string
4. Update `DATABASE_URL` in Vercel environment variables

## Project Structure

```
blacklord-tech-inc/
├── client/                 # React frontend
│   ├── src/
│   │   ├── pages/         # Page components
│   │   ├── components/    # Reusable components
│   │   ├── lib/           # Utilities and tRPC client
│   │   └── App.tsx        # Main app component
│   └── index.html
├── server/                # Express backend
│   ├── routers.ts         # tRPC procedures
│   ├── db.ts              # Database queries
│   └── _core/             # Core infrastructure
├── drizzle/               # Database schema and migrations
├── shared/                # Shared types and constants
├── package.json
├── tsconfig.json
├── vite.config.ts
└── vercel.json
```

## Key Features

- **Dark Cyberpunk UI**: Neon cyan and purple accents with fire/coal background
- **User Authentication**: Manus OAuth with session management
- **Wallet System**: KSH balance tracking with transaction history
- **Payment Integration**: Paystack, M-Pesa STK Push, Pesapal (stubs ready for API keys)
- **Product Management**: Pterodactyl hosting panels and automation bots
- **Admin Panel**: User, transaction, and order management
- **Role-Based Access**: Admin and user roles with protected routes

## API Endpoints

All endpoints are tRPC procedures. Access them via `/api/trpc/`

### Authentication
- `auth.me` - Get current user
- `auth.logout` - Logout user

### Wallet
- `wallet.getBalance` - Get user wallet balance
- `wallet.getHistory` - Get transaction history
- `wallet.deposit` - Initiate deposit
- `wallet.confirmDeposit` - Confirm payment

### Products
- `products.list` - List all products
- `products.getById` - Get product details

### Orders
- `orders.create` - Create new order
- `orders.list` - Get user orders

### Admin (Role-gated)
- `admin.users` - List all users
- `admin.transactions` - List all transactions
- `admin.orders` - List all orders

## Payment Integration

### Paystack
1. Get API key from [paystack.com](https://paystack.com)
2. Add to environment variables
3. Implement webhook handler in `server/routers.ts`

### M-Pesa STK Push
1. Get credentials from Safaricom
2. Add to environment variables
3. Implement STK push logic in payment handler

### Pesapal
1. Get API key from [pesapal.com](https://pesapal.com)
2. Add to environment variables
3. Implement payment redirect in payment handler

## Troubleshooting

### Build Fails
- Ensure all environment variables are set
- Check database connection string
- Run `pnpm install` to ensure dependencies are installed

### Database Connection Error
- Verify `DATABASE_URL` is correct
- Ensure database server is running
- Check firewall rules allow connection

### OAuth Not Working
- Verify `VITE_APP_ID` and `OAUTH_SERVER_URL` are correct
- Check callback URL is registered in OAuth provider

## Support

For issues or questions, refer to:
- [Manus Documentation](https://manus.im/docs)
- [tRPC Documentation](https://trpc.io)
- [Vercel Documentation](https://vercel.com/docs)

## License

MIT
