# BLACKLORD TECH INC - Flat File Structure

This ZIP contains **137 plain files** with NO folders. All files are flattened using a naming convention where folder paths are replaced with dashes.

## File Naming Convention

Files are named by replacing folder separators (/) with dashes (-):

**Examples:**
- `client/src/App.tsx` → `client-src-App.tsx`
- `server/routers.ts` → `server-routers.ts`
- `client/src/pages/Home.tsx` → `client-src-pages-Home.tsx`
- `client/src/components/ProductCard.tsx` → `client-src-components-ProductCard.tsx`
- `drizzle/schema.ts` → `drizzle-schema.ts`

## How to Use These Files

### Option 1: Reconstruct the Folder Structure (Recommended)

Extract and run this script to restore the original folder structure:

```bash
#!/bin/bash
# Extract the ZIP
unzip blacklord-tech-inc-flat.zip -d blacklord-tech-inc

# Recreate folder structure
cd blacklord-tech-inc
for file in *; do
  # Replace dashes with slashes to get original path
  original_path=$(echo "$file" | sed 's/-/\//g')
  
  # Create directory if it doesn't exist
  mkdir -p "$(dirname "$original_path")"
  
  # Move file to correct location
  mv "$file" "$original_path"
done

# Now you have the full project structure
cd ..
```

### Option 2: Use Files As-Is

If you want to use the flat structure directly, you'll need to:

1. Create the folder structure manually
2. Move files to their correct locations based on the naming convention

## File Categories

### Configuration Files (Root Level)
- `package.json` - Dependencies and scripts
- `tsconfig.json` - TypeScript configuration
- `vite.config.ts` - Vite bundler configuration
- `vitest.config.ts` - Test configuration
- `drizzle.config.ts` - Database configuration
- `vercel.json` - Vercel deployment config
- `components.json` - shadcn/ui configuration
- `template.json` - Project template config

### Frontend Files (client-*)
- `client-index.html` - Main HTML file
- `client-src-App.tsx` - Main React app
- `client-src-main.tsx` - React entry point
- `client-src-index.css` - Global styles with neon animations
- `client-src-pages-*.tsx` - Page components (Home, Dashboard, Wallet, Products, Admin, etc.)
- `client-src-components-*.tsx` - Reusable UI components
- `client-src-lib-*.ts` - Utilities and tRPC client
- `client-src-hooks-*.ts` - Custom React hooks
- `client-src-contexts-*.tsx` - React contexts

### Backend Files (server-*)
- `server-routers.ts` - tRPC procedures
- `server-db.ts` - Database queries
- `server-seed-products.ts` - Database seeding
- `server-_core-*.ts` - Core infrastructure (OAuth, cookies, etc.)
- `server-auth.logout.test.ts` - Test example

### Database Files (drizzle-*)
- `drizzle-schema.ts` - Table definitions
- `drizzle-*.sql` - Migration files
- `drizzle-relations.ts` - Table relationships

### Shared Files (shared-*)
- `shared-const.ts` - Constants
- `shared-types.ts` - Shared types
- `shared-_core-errors.ts` - Error types

### Documentation
- `README_FULL.md` - Complete documentation
- `DEPLOYMENT_GUIDE.md` - Vercel deployment guide
- `IMPLEMENTATION_NOTES.md` - Technical details
- `README-FLAT-STRUCTURE.md` - This file

## Quick Start

### 1. Reconstruct the Project
```bash
# Extract ZIP
unzip blacklord-tech-inc-flat.zip -d project

# Run the reconstruction script above
# This creates the proper folder structure

# Install dependencies
cd project
pnpm install

# Set up environment variables
cp .env.example .env
# Edit .env with your database URL

# Initialize database
pnpm drizzle-kit generate
pnpm drizzle-kit migrate
pnpm seed

# Start development
pnpm dev
```

### 2. Deploy to Vercel
```bash
# Push to GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/yourusername/blacklord-tech-inc.git
git push -u origin main

# Connect to Vercel and deploy
```

## File Count

Total files: **137 plain files**

Breakdown by category:
- Configuration files: 8
- Frontend files: 70+
- Backend files: 15+
- Database files: 5
- Shared files: 3
- Documentation: 4

## Key Features

✨ **Dark Cyberpunk UI**
- Neon glow effects on product cards
- Smooth animations and transitions
- Fire/coal background image

💳 **Payment System**
- Paystack, M-Pesa, Pesapal integration stubs

👤 **User Management**
- Manus OAuth authentication
- Role-based access control

📊 **Admin Dashboard**
- User, transaction, and order management

## Support

For issues or questions:
1. Reconstruct the folder structure first
2. Check DEPLOYMENT_GUIDE.md
3. Review README_FULL.md
4. Check IMPLEMENTATION_NOTES.md

---

**BLACKLORD TECH INC** - Powering the future of hosting and automation. 🚀
