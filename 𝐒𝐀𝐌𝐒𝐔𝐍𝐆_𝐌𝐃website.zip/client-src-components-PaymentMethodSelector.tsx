import { CreditCard, Smartphone, Globe } from "lucide-react";

interface PaymentMethodSelectorProps {
  selected: "paystack" | "mpesa" | "pesapal";
  onChange: (method: "paystack" | "mpesa" | "pesapal") => void;
}

export function PaymentMethodSelector({ selected, onChange }: PaymentMethodSelectorProps) {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {/* M-Pesa STK Push */}
      <button
        onClick={() => onChange("mpesa")}
        className={`p-4 rounded-lg border-2 transition ${
          selected === "mpesa"
            ? "border-cyan-500 bg-cyan-500/10"
            : "border-cyan-500/30 bg-black/30 hover:border-cyan-500/60"
        }`}
      >
        <Smartphone className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
        <div className="font-semibold">M-Pesa</div>
        <div className="text-xs text-gray-400">STK Push</div>
      </button>

      {/* Paystack */}
      <button
        onClick={() => onChange("paystack")}
        className={`p-4 rounded-lg border-2 transition ${
          selected === "paystack"
            ? "border-purple-500 bg-purple-500/10"
            : "border-cyan-500/30 bg-black/30 hover:border-cyan-500/60"
        }`}
      >
        <CreditCard className="w-6 h-6 mx-auto mb-2 text-purple-400" />
        <div className="font-semibold">Paystack</div>
        <div className="text-xs text-gray-400">Card/Bank</div>
      </button>

      {/* Pesapal */}
      <button
        onClick={() => onChange("pesapal")}
        className={`p-4 rounded-lg border-2 transition ${
          selected === "pesapal"
            ? "border-cyan-500 bg-cyan-500/10"
            : "border-cyan-500/30 bg-black/30 hover:border-cyan-500/60"
        }`}
      >
        <Globe className="w-6 h-6 mx-auto mb-2 text-cyan-400" />
        <div className="font-semibold">Pesapal</div>
        <div className="text-xs text-gray-400">Multiple</div>
      </button>
    </div>
  );
}
