import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Loader2, Users, TrendingUp, Package, BarChart3 } from "lucide-react";
import { useEffect } from "react";

export default function Admin() {
  const { user, loading: authLoading } = useAuth();
  const { data: usersData } = trpc.admin.users.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });
  const { data: transactionsData } = trpc.admin.transactions.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });
  const { data: ordersData } = trpc.admin.orders.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "admin")) {
      window.location.href = "/";
    }
  }, [user, authLoading]);

  if (authLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  const users = usersData?.users || [];
  const transactions = transactionsData?.transactions || [];
  const orders = ordersData?.orders || [];

  const totalRevenue = orders.reduce((sum: number, o: any) => sum + parseFloat(o.totalPrice), 0);
  const totalDeposits = transactions
    .filter((t: any) => t.type === "deposit" && t.status === "completed")
    .reduce((sum: number, t: any) => sum + parseFloat(t.amount), 0);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-cyan-500/30 bg-black/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              BLACKLORD TECH
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/dashboard">
              <Button variant="outline" size="sm" className="border-cyan-500 text-cyan-400">
                Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center gap-3 mb-8">
          <BarChart3 className="w-8 h-8 text-cyan-400" />
          <h1 className="text-4xl font-bold">Admin Dashboard</h1>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-black/50 border-cyan-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400 mb-2">Total Users</div>
                <div className="text-3xl font-bold text-cyan-400">{users.length}</div>
              </div>
              <Users className="w-8 h-8 text-cyan-400/50" />
            </div>
          </Card>

          <Card className="bg-black/50 border-purple-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400 mb-2">Total Orders</div>
                <div className="text-3xl font-bold text-purple-400">{orders.length}</div>
              </div>
              <Package className="w-8 h-8 text-purple-400/50" />
            </div>
          </Card>

          <Card className="bg-black/50 border-cyan-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400 mb-2">Total Revenue</div>
                <div className="text-2xl font-bold text-cyan-400">
                  KSH {(totalRevenue / 1000).toFixed(1)}k
                </div>
              </div>
              <TrendingUp className="w-8 h-8 text-cyan-400/50" />
            </div>
          </Card>

          <Card className="bg-black/50 border-purple-500/30 p-6">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400 mb-2">Total Deposits</div>
                <div className="text-2xl font-bold text-purple-400">
                  KSH {(totalDeposits / 1000).toFixed(1)}k
                </div>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400/50" />
            </div>
          </Card>
        </div>

        {/* Management Sections */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Link href="/admin/users">
            <Card className="bg-black/50 border-cyan-500/30 hover:border-cyan-500/60 transition p-6 cursor-pointer">
              <div className="flex items-center gap-4">
                <Users className="w-12 h-12 text-cyan-400" />
                <div>
                  <h3 className="text-xl font-bold mb-1">Users</h3>
                  <p className="text-gray-400 text-sm">{users.length} registered users</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/admin/transactions">
            <Card className="bg-black/50 border-purple-500/30 hover:border-purple-500/60 transition p-6 cursor-pointer">
              <div className="flex items-center gap-4">
                <TrendingUp className="w-12 h-12 text-purple-400" />
                <div>
                  <h3 className="text-xl font-bold mb-1">Transactions</h3>
                  <p className="text-gray-400 text-sm">{transactions.length} total transactions</p>
                </div>
              </div>
            </Card>
          </Link>

          <Link href="/admin/orders">
            <Card className="bg-black/50 border-cyan-500/30 hover:border-cyan-500/60 transition p-6 cursor-pointer">
              <div className="flex items-center gap-4">
                <Package className="w-12 h-12 text-cyan-400" />
                <div>
                  <h3 className="text-xl font-bold mb-1">Orders</h3>
                  <p className="text-gray-400 text-sm">{orders.length} total orders</p>
                </div>
              </div>
            </Card>
          </Link>
        </div>

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Orders */}
          <Card className="bg-black/50 border-cyan-500/30 p-6">
            <h3 className="text-xl font-bold mb-4">Recent Orders</h3>
            <div className="space-y-3">
              {orders.slice(0, 5).map((order: any) => (
                <div key={order.id} className="pb-3 border-b border-cyan-500/20 last:border-0">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="font-medium">Order #{order.id}</div>
                      <div className="text-xs text-gray-400">User #{order.userId}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-cyan-400">
                        KSH {parseFloat(order.totalPrice).toLocaleString("en-KE", { minimumFractionDigits: 2 })}
                      </div>
                      <div className="text-xs text-gray-400">{order.status}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* Recent Transactions */}
          <Card className="bg-black/50 border-purple-500/30 p-6">
            <h3 className="text-xl font-bold mb-4">Recent Deposits</h3>
            <div className="space-y-3">
              {transactions
                .filter((t: any) => t.type === "deposit")
                .slice(0, 5)
                .map((tx: any) => (
                  <div key={tx.id} className="pb-3 border-b border-purple-500/20 last:border-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium">Deposit #{tx.id}</div>
                        <div className="text-xs text-gray-400">{tx.paymentMethod || "System"}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-green-400">
                          +KSH {parseFloat(tx.amount).toLocaleString("en-KE", { minimumFractionDigits: 2 })}
                        </div>
                        <div className={`text-xs ${
                          tx.status === "completed" ? "text-green-400" :
                          tx.status === "pending" ? "text-yellow-400" :
                          "text-red-400"
                        }`}>
                          {tx.status}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
