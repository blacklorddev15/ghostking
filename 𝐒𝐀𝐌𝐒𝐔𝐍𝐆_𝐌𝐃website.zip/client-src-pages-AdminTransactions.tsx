import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { Loader2, TrendingUp, ArrowLeft } from "lucide-react";
import { useEffect } from "react";

export default function AdminTransactions() {
  const { user, loading: authLoading } = useAuth();
  const { data: transactionsData, isLoading } = trpc.admin.transactions.useQuery(undefined, {
    enabled: !!user && user.role === "admin",
  });

  useEffect(() => {
    if (!authLoading && (!user || user.role !== "admin")) {
      window.location.href = "/";
    }
  }, [user, authLoading]);

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  const transactions = transactionsData?.transactions || [];
  const totalDeposits = transactions
    .filter((t: any) => t.type === "deposit" && t.status === "completed")
    .reduce((sum: number, t: any) => sum + parseFloat(t.amount), 0);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="border-b border-cyan-500/30 bg-black/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <a className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              BLACKLORD TECH
            </a>
          </Link>
          <div className="flex gap-4">
            <Link href="/admin">
              <Button variant="outline" size="sm" className="border-cyan-500 text-cyan-400">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Admin Panel
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-12">
        <div className="flex items-center gap-3 mb-8">
          <TrendingUp className="w-8 h-8 text-cyan-400" />
          <h1 className="text-4xl font-bold">Transaction Management</h1>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-black/50 border-cyan-500/30 p-6">
            <div className="text-sm text-gray-400 mb-2">Total Transactions</div>
            <div className="text-3xl font-bold text-cyan-400">{transactions.length}</div>
          </Card>
          <Card className="bg-black/50 border-purple-500/30 p-6">
            <div className="text-sm text-gray-400 mb-2">Total Deposits</div>
            <div className="text-3xl font-bold text-purple-400">
              KSH {totalDeposits.toLocaleString("en-KE", { minimumFractionDigits: 2 })}
            </div>
          </Card>
          <Card className="bg-black/50 border-cyan-500/30 p-6">
            <div className="text-sm text-gray-400 mb-2">Completed</div>
            <div className="text-3xl font-bold text-cyan-400">
              {transactions.filter((t: any) => t.status === "completed").length}
            </div>
          </Card>
        </div>

        {/* Transactions Table */}
        <Card className="bg-black/50 border-cyan-500/30 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-black/80 border-b border-cyan-500/30">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold">ID</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">User ID</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">Type</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">Amount</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">Method</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold">Date</th>
                </tr>
              </thead>
              <tbody>
                {transactions.length > 0 ? (
                  transactions.map((tx: any) => (
                    <tr key={tx.id} className="border-b border-cyan-500/10 hover:bg-cyan-500/5 transition">
                      <td className="px-6 py-4 text-sm">{tx.id}</td>
                      <td className="px-6 py-4 text-sm">{tx.userId}</td>
                      <td className="px-6 py-4 text-sm capitalize">{tx.type}</td>
                      <td className="px-6 py-4 text-sm font-medium">
                        KSH {parseFloat(tx.amount).toLocaleString("en-KE", { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-400">{tx.paymentMethod || "System"}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`px-3 py-1 rounded text-xs font-medium ${
                          tx.status === "completed" ? "bg-green-500/20 text-green-400" :
                          tx.status === "pending" ? "bg-yellow-500/20 text-yellow-400" :
                          "bg-red-500/20 text-red-400"
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-400">
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                      No transactions found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}
